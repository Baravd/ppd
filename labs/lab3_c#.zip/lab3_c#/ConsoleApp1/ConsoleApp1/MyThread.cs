﻿namespace ConsoleApp1
{
    public class MyThread
    {
        
    }
}